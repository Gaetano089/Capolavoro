import express from "express"
import bodyParser from "body-parser";

const CWD = process.cwd() + "/";

var app = express()

var data = "spento\n0";

app.use((req, res, next) => 
{
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});
app.use(bodyParser.urlencoded({extended: true}));

app.get("/SetStatus", (req, res) =>
{

    res.sendFile(CWD + "NodeServer/StatusServer/StaticPages/SetStatus.html");

});

app.post("/SetStatus", (req, res) =>
{

    data = req.body.status + "\n" + req.body.frameNum;

    res.sendFile(CWD + "NodeServer/StatusServer/StaticPages/RedirectToServerStatus.html");

});

app.get("/java_set_status", (req, res) =>
{

    data = req.query.status + "\n" + req.query.frameNum;

    res.send("gg");

});

app.get("/*", (req, res) =>
{

    res.send(data);

});

const PORT = 5001;
app.listen(PORT, () =>
{

    console.log("listening at localhost:" + PORT);

});