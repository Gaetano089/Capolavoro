import express from "express"
import url from "url"
import fs from "fs"
import session from "express-session"
import { exec } from "child_process"

const CWD = process.cwd() + "/";

const CREDENZIALI = JSON.parse(fs.readFileSync(CWD + "StaticPages/Accesso/Credenziali.json").toString("utf-8"));

function AvviaServer()
{

    exec("start StartJavaServer.bat");

}

var app = express()
app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: true }
}));

app.get("/DownloadClient", (req, res) =>
{

    res.download(CWD + "JavaApps/Client/Client.jar");

});

app.get("/StatoServer", (req, res) =>
{

    res.sendFile(CWD + "StaticPages/StatoServer.html");

});

app.get("/GetResources/Icons/*", (req, res) =>
{

    var color = req.url.substring(req.url.lastIndexOf("/") + 1).toLowerCase();

    var file = fs.readFileSync(CWD + "StaticPages/Resources/Icons/icon.svg").toString("utf-8");

    var result = file.replace("%s", color);

    res.contentType("svg");

    res.send(result);

});

app.get("/AvviaServer", (req, res) =>
{

    if(req.session.logged == undefined || req.session.logged == false)
        res.sendFile(CWD + "StaticPages/Accesso/Login.html");
    else
        res.redirect("/StatoServer");

});

app.post("/AvviaServer", (req, res) =>
{

    var username = req.body.username;
    var password = req.body.password;

    req.session.logged = false;

    if(CREDENZIALI[username] != undefined && password == CREDENZIALI[username])
    {
        req.session.logged = true;

        AvviaServer();

        res.redirect("/StatoServer");
    }
    else
        res.redirect("/AvviaServer");

});

app.get("/*", (req, res) =>
{

    res.sendFile(CWD + "StaticPages/Home.html");

});

const PORT = 5000;
app.listen(PORT, () =>
{

    console.log("listening at localhost:" + PORT);

});

exec("start node NodeServer/StatusServer/Server.js");