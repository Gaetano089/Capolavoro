package JavaApps.Client;

import java.awt.Point;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@SuppressWarnings({"resource"})
public class Client 
{

    public static final int PORT = 50_000;

    public static short[] velocitiesX = new short[100], velocitiesY = new short[100];
    public static Vector<Point> positions;

    public static final float PARTICLE_MASS = 100;
    public static final float PARTICLE_MASS_SQ = PARTICLE_MASS * PARTICLE_MASS;

    public static ThreadPoolExecutor threadPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    public static int id = 0;

    public static ThreadPoolExecutor pool = (ThreadPoolExecutor) Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    
    public static void main(String... args) throws Exception
    {

        Scanner cmdIn = new Scanner(System.in);

        System.out.println("Inserire il nomeHost a cui connettersi");
        String nomeHost = cmdIn.nextLine();

        Socket connection = new Socket(nomeHost, PORT);

        PrintWriter connectionOut = new PrintWriter(connection.getOutputStream());
        Scanner connectionIn = new Scanner(connection.getInputStream());

        Set<Callable<String>> tasks = new HashSet<>();
        
        for(int i = 0; i < 100; i++)
            tasks.add(new CustomCallable(i));

        while(connection.isClosed() == false)
        {

            Simulate(connectionOut, connectionIn, tasks);

        }

        connection.close();

    }

    public static void Simulate(PrintWriter connectionOut, Scanner connectionIn, Set<Callable<String>> tasks) throws InterruptedException
    {

        while(connectionIn.hasNextLine() == false);

        String nextLine = connectionIn.nextLine();

        String[] data = nextLine.split("|");

        String positionsXString = data[0];
        String positionsYString = data[1];
        id = Integer.parseInt(data[2]);

        String[] positionsXStrings = positionsXString.split(",");
        String[] positionsYStrings = positionsYString.split(",");

        if(positions.isEmpty())
        {

            for(int i = 0; i < positionsXStrings.length; i++)
            {

                positions.add(new Point(Short.parseShort(positionsXStrings[i]), Short.parseShort(positionsYStrings[i])));

            }

        }

        for(int i = 0; i < positionsXStrings.length; i++)
        {

            positions.get(i).x = Short.parseShort(positionsXStrings[i]);
            positions.get(i).y = Short.parseShort(positionsYStrings[i]);

        }

        threadPool.invokeAll(tasks);
        threadPool.awaitTermination(100, TimeUnit.SECONDS);

        System.gc();

    }

}

final class CustomCallable implements Callable<String>
{

    public int id, callableId;
    public static Vector<Point> positions = Client.positions;

    public static final double G = 6.674e-11;

    public static final double NUMERATOR = G * Client.PARTICLE_MASS_SQ;

    public CustomCallable(int callableId)
    {

        this.id = positions.size() / 100 * Client.id + callableId;
        this.callableId = callableId;

    }

    public String call() throws Exception
    {

        double F, fx = 0.0, fy = 0.0;
        double distSq;
        double xDist, yDist;
        double totalDist;

        for(int i = 0; i < positions.size(); i++)
        {

            xDist = positions.get(id).x - positions.get(i).x;
            yDist = positions.get(id).y - positions.get(i).y;

            distSq = (xDist * xDist) - (yDist * yDist);

            if(Client.PARTICLE_MASS_SQ < distSq)
                continue;

            F = NUMERATOR / distSq;

            if(F < 0.1)
                continue;

            xDist = Math.abs(xDist);
            yDist = Math.abs(yDist);
            totalDist = xDist + yDist;

            fx += F * (xDist / totalDist);
            fy += F * (yDist / totalDist);

        }

        int nextXPosition = positions.get(id).x + Client.velocitiesX[callableId];
        int nextYPosition = positions.get(id).y + Client.velocitiesY[callableId];

        if(nextXPosition >= 1280 || nextXPosition <= 0)
        {
            Client.velocitiesX[callableId] *= -1;
            nextXPosition = positions.get(id).x + Client.velocitiesX[callableId];
        }
        
        if(nextYPosition >= 720 || nextYPosition <= 0)
        {
            Client.velocitiesY[callableId] *= -1;
            nextYPosition = positions.get(id).y + Client.velocitiesY[callableId];
        }

        positions.get(id).x = nextXPosition;
        positions.get(id).y = nextYPosition;

        Client.velocitiesX[callableId] += (short) fx;
        Client.velocitiesY[callableId] += (short) fy;

        return "";

    }

}