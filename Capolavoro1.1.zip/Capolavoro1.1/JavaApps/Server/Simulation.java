package JavaApps.Server;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.SwingUtilities;

import static JavaApps.Server.Server.SetServerStatus;

@SuppressWarnings({"unused"})
public class Simulation 
{

    public static ThreadPoolExecutor pool = (ThreadPoolExecutor) Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    public static short[] positionsX, positionsY;

    public static final short WIDTH = 1280, HEIGHT = 720, PARTICLES_PER_CLIENT = 100;

    public static final int SIMULATION_DURATION = 10, FRAMERATE = 60;

    public static Encoder encoder = new Encoder();

    public static void Handle() throws Exception
    {

        Vector<Socket> clients = Server.clients;

        Vector<EnhancedSocket> enhancedClients = new Vector<>(clients.size());

        for(int i = 0; i < clients.size(); i++)
            enhancedClients.add(new EnhancedSocket(clients.get(i)));
        
        Callable<String> task = () -> RunClient(enhancedClients);
        Set<Callable<String>> tasks = new HashSet<>();
        
        for(int i = 0; i < clients.size(); i++)
            tasks.add(task);

        positionsX = new short[clients.size() * PARTICLES_PER_CLIENT];
        positionsY = new short[clients.size() * PARTICLES_PER_CLIENT];

        Random rand = new Random(System.nanoTime());

        for(int i = 0; i < clients.size(); i++)
        {

            positionsX[i] = (short) rand.nextInt(WIDTH);
            positionsY[i] = (short) rand.nextInt(HEIGHT);

        }

        for(int i = 0; i < SIMULATION_DURATION * FRAMERATE; i++)
        {

            SetServerStatus("acceso", i);

            RenderFrame(tasks, enhancedClients);

        }

        encoder.EncodeVideo();

    }

    public static boolean finishedRendering = false;

    public static void RenderFrame(Set<Callable<String>> tasks, Vector<EnhancedSocket> clients) throws Exception
    {

        pool.invokeAll(tasks);
        pool.awaitTermination(100, TimeUnit.SECONDS);

        BufferedImage currentFrame = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g = currentFrame.createGraphics();

        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_SPEED);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g.setColor(Color.black);

        g.fillRect(0, 0, WIDTH, HEIGHT);

        g.setColor(Color.white);

        SwingUtilities.invokeLater(() -> {finishedRendering = true;});

        for(int i = 0; i < positionsX.length; i++)
        {

            g.fillOval(positionsX[i], positionsY[i], 10, 10);

        }

        while(finishedRendering == false);

        g.dispose();

        encoder.AddFrame(currentFrame);

        finishedRendering = false;

    }

    public static String RunClient(Vector<EnhancedSocket> clients)
    {

        EnhancedSocket sock = null;

        int index;

        for(index = 0; index < clients.size(); index++)
            if(clients.get(index).done == false)
            {
                sock = clients.get(index);
                break;
            }

        sock.done = true;

        String send = "";

        for(int i = 0; i < positionsX.length; i++)
        {

            if(i+1 < positionsX.length)
                send += positionsX[i] + ",";
            else
                send += positionsX[i] + "|";

        }

        for(int i = 0; i < positionsY.length; i++)
        {

            if(i+1 < positionsY.length)
                send += positionsY[i] + ",";
            else
                send += positionsY[i] + "|";

        }

        send += index;

        sock.out.println(send);
        sock.out.flush();

        long timeout = System.currentTimeMillis() + 10_000;

        while(sock.in.hasNextLine() == false && System.currentTimeMillis() < timeout);

        String recv = sock.in.nextLine();

        String[] newPositionData = recv.split("|");

        String[] newPosXStrings = newPositionData[0].split(",");
        String[] newPosYStrings = newPositionData[1].split(",");

        for(int i = 0; i < positionsX.length; i++)
        {

            positionsX[i] = Short.parseShort(newPosXStrings[i]);
            positionsY[i] = Short.parseShort(newPosYStrings[i]);

        }

        recv = null;
        newPositionData = null;
        newPosXStrings = null;
        newPosYStrings = null;

        System.gc();

        return "";

    }

}

final class Encoder
{

    private Vector<BufferedImage> frames;
    public int frameNum;

    public Encoder()
    {

        frames = new Vector<>();
        frameNum = 0;

    }

    public void AddFrame(BufferedImage img) throws Exception
    {

        if(frames.size() == 60)
        {

            for(BufferedImage currImg : frames)
            {

                String cartellaFrames = System.getProperty("user.dir") + "/../../SimulationFrames/";

                File currFile = new File(cartellaFrames + "IMG_" + String.format("%05d", frameNum++) + ".jpg");

                ImageIO.write(currImg, "jpg", currFile);

            }

            frames.clear();

        }

        frames.add(img);

    }

    public Vector<BufferedImage> GetFrameArr() { return frames; }

    public void EncodeVideo() throws Exception
    {

        String[] cmd = {"ffmpeg -f image2 -r 60/1 -i ../../SimulationFrames/IMG_%05d.jpg ../../VideoSimulazione.mp4"};

        Runtime.getRuntime().exec(cmd).waitFor();

    }

}

final class EnhancedSocket
{

    public Socket socket;
    public PrintWriter out;
    public Scanner in;
    public boolean done;
    public int[] positions;

    public EnhancedSocket(Socket socket) throws IOException
    {

        this.socket = socket;

        out = new PrintWriter(socket.getOutputStream());

        in = new Scanner(socket.getInputStream());

        done = false;

        positions = new int[100];

    }

}