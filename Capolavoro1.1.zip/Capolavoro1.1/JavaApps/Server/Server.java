package JavaApps.Server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.Set;
import java.util.Vector;

@SuppressWarnings({"deprecation", "unused", "resource"})
public class Server
{

    public static final int PORT = 50_000;

    public static Path encodingServerPath = Path.of(System.getProperty("user.home")).resolve("simulation.socket");

    public static Thread shutDownThread = new Thread(new Runnable() {
        public void run()
        {
            try {
                Files.deleteIfExists(encodingServerPath);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    });

    static{
        Runtime.getRuntime().addShutdownHook(shutDownThread);
    }

    public static String stato = "spento\n0";

    public static Vector<Socket> clients = new Vector<>();

    public static void main(String... args) throws Exception
    {

        ServerSocket server = new ServerSocket(PORT);

        SetServerStatus("accendendo", 0);

        long expire = System.currentTimeMillis() + 10_000;

        while(System.currentTimeMillis() <= expire)
        {

            clients.add(server.accept());

        }

        SetServerStatus("acceso", 0);

        Simulation.Handle();

        SetServerStatus("spegnendo", 0);

        Thread.sleep(2500);

        SetServerStatus("spento", 0);

    }

    public static void SetServerStatus(String status, int frameNum) throws IOException
    {

        URL url = new URL("http://localhost:5001/java_set_status?status="+status+"&frameNum="+frameNum);

        URLConnection connection = url.openConnection();

        InputStream is = connection.getInputStream();

        connection.connect();

        is.read();

        System.gc();

    }

}