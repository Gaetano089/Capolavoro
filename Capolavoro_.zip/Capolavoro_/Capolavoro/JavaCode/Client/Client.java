import java.awt.Point;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Client 
{

    public static final Point[] positions = new Point[100];
    public static final Point[] velocities = new Point[positions.length];

    public static final long MASSA = 1_000_000, MASS_SQ = MASSA*MASSA;
    public static final long G_SHIFT = 34; // Shifting 34 places right is the same as multiplying by G

    public static final int WIDTH = 1280, HEIGHT = 720;
    public static final int FRAME_COUNT = 60 * 60;

    public static int frameCounter = 0;

    public static final ArrayList<Point> points = new ArrayList<>();

    static {

        Random rand = new Random(System.currentTimeMillis());

        for(int i = 0; i < positions.length; i++)
        {
            positions[i] = new Point(rand.nextInt(WIDTH), rand.nextInt(HEIGHT));
            velocities[i] = new Point(0, 0);
        }

    }

    public static void main(String... args) throws Exception
    {

        for(int i = 0; i < FRAME_COUNT; i++)
            Simulate();    
        
        try (Socket dataSocket = new Socket("127.0.0.1", 8080)) 
        {
            
            String request = """
                    POST /Capolavoro/Simulation HTTP/1.1
                    Host: localhost
                    Content-Type: text/plain
                    Content-Length: %d\n\n
                    """;
            
            String tmp = "";
            
            long[] positionsArray = new long[points.size() * 2];
            for(int i = 0; i < points.size(); i+=2)
            {
                
                positionsArray[i + 0] = points.get(i).x;
                positionsArray[i + 1] = points.get(i).y;
                
            }
            
            String arrayString = Arrays.toString(positionsArray);
            
            arrayString = arrayString.substring(1, arrayString.length()-2);
            
            tmp += arrayString;
            
            request += tmp;
            
            request = String.format(request, tmp.length());
            
            System.out.println(request.substring(0, 200));
            
            dataSocket.getOutputStream().write(request.getBytes(StandardCharsets.UTF_8));
            
            System.gc();
        }

    }

    public static void Simulate()
    {

        long distSq;
        long xDist, yDist, distSum;
        long F;
        double xMult, yMult;
        short xDir, yDir;

        for(int i = 0; i < positions.length; i++)
        {

            positions[i].x += velocities[i].x;
            positions[i].y += velocities[i].y;

            for (Point position : positions) 
            {
                xDist = positions[i].x - position.x;
                yDist = positions[i].y - position.y;
                distSq = xDist * xDist + yDist * yDist;
                if(distSq == 0)
                    continue;
                F = (MASS_SQ / distSq) >> G_SHIFT;
                if(F < 5)
                    continue;
                distSum = xDist + yDist;
                xMult = (double)xDist / (double)distSum;
                yMult = (double)yDist / (double)distSum;
                xDir = (short) (positions[i].x > position.x ? 1 : -1);
                yDir = (short) (positions[i].y > position.y ? 1 : -1);
                velocities[i].x += (double)F * xMult * xDir;
                velocities[i].y += (double)F * yMult * yDir;
            }

        }

        points.addAll(Arrays.asList(positions));

        System.out.println("Renderizzando il frame" + frameCounter++);

    }
    
}
