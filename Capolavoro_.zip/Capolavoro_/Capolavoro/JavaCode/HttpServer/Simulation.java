import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/Simulation")
public class Simulation extends HttpServlet
{

    public static final int MAX_WAIT_TIME = 5000; /*5 seconds*/

    public static ArrayList<int[]> frames = new ArrayList<>();
    public static long lastSended = -1;

    // -2: spento
    // -3: spegnendo
    // -1 accendendo
    // >= 0: acceso (il numero indica il numero del frame renderizzato)
    public static long serverStatus = -2;

    public static HashMap<String, Integer> ids = new HashMap<>();
    public static int id = 0;

    // Usato per ottenere l'id dell'host che lo chiama
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        System.out.println("Ho ricevuto qualcosa!");

        BufferedReader requestReader = new BufferedReader(new InputStreamReader(request.getInputStream()));

        String requestString = "";

        String lineRead;

        while((lineRead = requestReader.readLine()) != null)
        {

            requestString += lineRead + "\n";

        }

        requestReader.close();

        String parameter = requestString.substring(requestString.length() - Integer.parseInt(request.getHeader("Content-Length"))).replaceAll("\\s", "");

        //System.out.println("Primi 100 caratteri del body: " + parameter.substring(0, 100));

        if(lastSended == -1)
            lastSended = System.currentTimeMillis();

        if(lastSended + MAX_WAIT_TIME <= System.currentTimeMillis())
        {

            VideoRenderer.StartRendering(frames, request.getServletContext().getResource("/resources").getPath());

            return;

        }

        lastSended = System.currentTimeMillis();

        String[] data = parameter.split(",");

        requestReader = null;
        lineRead = null;
        requestString = null;
        parameter = null;

        System.gc();

        int[] positions = new int[data.length];

        for(int i = 0; i < positions.length; i++)
            positions[i] = Integer.parseInt(data[i]);

        for(int i = 0; i < data.length; i++)
            data[i] = null;

        data = null;

        System.gc();

        frames.add(positions);
    
        System.gc();

    }

}
