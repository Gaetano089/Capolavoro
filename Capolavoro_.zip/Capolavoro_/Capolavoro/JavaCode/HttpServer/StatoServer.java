import javax.servlet.http.*;
import java.io.IOException;
import javax.servlet.annotation.*;

@WebServlet("/StatoServer")
public class StatoServer extends HttpServlet
{
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        if(request.getParameter("calledFromCode") == null)
        {

            Home.SendFile("/resources/StaticPages/StatoServer.html", request, response);

        }
        else
        {

            response.getOutputStream().print(Simulation.serverStatus);
            response.getOutputStream().flush();

        }    

    }

}
