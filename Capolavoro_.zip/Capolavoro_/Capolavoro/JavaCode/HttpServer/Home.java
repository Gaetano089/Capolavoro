import javax.servlet.http.*;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;
import javax.servlet.annotation.*;

@WebServlet("/Home")
public class Home extends HttpServlet
{

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        SendFile("/resources/StaticPages/Home.html", request, response);

    }

    public static void SendFile(String path, HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        InputStream in = request.getServletContext().getResourceAsStream(path);
        
        Scanner scanner = new Scanner(in).useDelimiter("\\A");

        String page = scanner.hasNext() ? scanner.next() : "file vuoto o assente";

        response.getOutputStream().print(page);

    }

}