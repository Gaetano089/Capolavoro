import javax.servlet.http.*;
import java.io.IOException;
import java.util.HashMap;
import javax.servlet.annotation.*;

@WebServlet("/AvvioServer")
public class AvvioServer extends HttpServlet
{

    public static boolean serverStarted = false;
    
    public static final HashMap<String, String> credenziali = new HashMap<>();

    static {

        credenziali.put("__ADMIN__", "__ADMIN__");

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        Home.SendFile("/resources/StaticPages/Accesso.html", request, response);

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if(credenziali.containsKey(username) && credenziali.get(username).equals(password))
        {

            StartServer();

            response.sendRedirect("/Capolavoro/StatoServer");

        }
        else
            response.sendRedirect("/Capolavoro/AvvioServer");

    }

    public static void StartServer()
    {

        serverStarted = true;

        

        serverStarted = false;

    }

}
