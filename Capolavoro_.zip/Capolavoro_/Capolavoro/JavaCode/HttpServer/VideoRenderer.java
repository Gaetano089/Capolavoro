import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class VideoRenderer 
{
    
    public static final int WIDTH = 1280, HEIGHT = 720;
    private static final int RADIUS = 10;
    public static boolean rendering = false;

    public static void StartRendering(ArrayList<int[]> framePositions, String path) throws IOException
    {

        System.out.println("Rendering avviato!");

        if(rendering)
            return;

        rendering = true;

        int partSize = framePositions.get(0).length/200;

        BufferedImage[] frames = new BufferedImage[partSize];

        for(int i = 0; i < frames.length; i++)
            frames[i] = new BufferedImage(1280, 720, BufferedImage.TYPE_INT_ARGB);
        
        Point p = new Point();

        System.out.println("Percorso arrivato alla funzione: " + path);

        for (int i = 0; i < frames.length; i++) 
        {

            Graphics2D g = frames[i].createGraphics();

            g.setColor(Color.black);
            g.fillRect(0, 0, WIDTH, HEIGHT);
            g.setColor(Color.magenta);

            for(int j = partSize * i; j < partSize * (i+1); i+=2)
            {

                for(int k = 0; k < framePositions.size(); k++)
                {

                    p.x = framePositions.get(k)[j+0];
                    p.y = framePositions.get(k)[j+1];

                    g.fillOval(p.x, p.y, RADIUS, RADIUS);

                }

            }

            g.dispose();
            frames[i].flush();

            File f = new File("C:/users/gaetano/desktop/Capolavoro_/XAMPP/tomcat/webapps/Capolavoro/resources" + "/Frames/img" + i + ".jpg");

            System.out.println("Scrivendo sul file: " + f.getAbsolutePath());

            ImageIO.write(frames[i], "jpg", f);

        }

    }

}
